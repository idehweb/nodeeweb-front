const types = {
  Home: "HomeData",
  Receive: "ReceiveData",
  Error: "ErrorData",
  SaveData: "SaveData"
};

export default types;
