import React from 'react';


import {withTranslation} from 'react-i18next';

const Test = ({}) => {

  return (
    <div>jjjj</div>
  );
};

export default withTranslation()(Test);
